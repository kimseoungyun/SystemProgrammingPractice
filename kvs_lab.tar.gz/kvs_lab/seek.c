#include "kvs.h"
int seek(kvs_t* kvs)
{
	node_t* tmp;
	node_t* curn_node;
	node_t* next_p;
	char tmp_key[100];
	char *tmp_value = malloc(sizeof(char)*20);
	node_t* tmp3;
	//마지막 노드의 다음은 NULL값으로 정해주기
	tmp = kvs ->db;
    for(int i=0;i<kvs->items;i++)
    {
		printf("%s %s\n", tmp->key, tmp->value);
		tmp=tmp->next;
    }
	printf("hereee\n");
	tmp = NULL;
	//버블정렬
    for (curn_node=kvs->db; curn_node!=NULL; )
    {
        for (next_p = curn_node; next_p != NULL;)
        {	
			//왼쪽이 더 크다면
            if(strcmp(next_p->key, curn_node->key)<0)
            {
                strcpy(tmp_key, next_p->key);
				tmp_value = next_p->value;
				strcpy(next_p ->key, curn_node->key);
				strcpy(next_p ->value, curn_node->value);
				strcpy(curn_node->key, tmp_key);
				curn_node->value = tmp_value;
				break;
            }
			next_p = next_p->next;
        }
		curn_node = curn_node->next;
    }
	//출력하기
	tmp3 = kvs ->db;
    for(int i=0;i<kvs->items;i++)
    {
		printf("(%s %s)\n", tmp3->key, tmp3->value);
    	tmp3=tmp3->next;
    }	

	return 0;
}
