#include "kvs.h"

int close(kvs_t* kvs)
{	
	struct node* tmp1;
	struct node* tmp2;
	
	tmp1 = kvs->db;
	tmp2 = kvs->db;
	if(tmp1->next==NULL){
		free(tmp1);	
		return 0;
	}
	while(tmp2!=NULL){
		tmp2 = tmp1->next;
		free(tmp1);
		tmp1=tmp2;
	}
	return 0;
}
