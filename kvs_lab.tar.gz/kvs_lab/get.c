#include "kvs.h"

char* get(kvs_t* kvs, const char* key)
{
	char* value = (char*)malloc(sizeof(char)*100);	

	//마지막 위치 찾으러 가며 리턴하기
	struct node* tmp=kvs->db;
	for(int i =0; i<kvs->items;i++)
	{	
		if((strcmp(tmp->key, key))==0)
		{
			value = tmp->value;
			return value;
		}
		if(i!=kvs->items-1){
			 tmp=tmp->next;
		}
	}

    if(!value){
        printf("Failed to malloc\n");
        return NULL;
    }

	strcpy(value, "deadbeaf");
	return value;
}
