#include "kvs.h"
#include<dlfcn.h>

int main()
{
	// 1. create KVS
	void *handle;
	kvs_t* (*open)();
	int (*put)(kvs_t*, const char*, const char*);
	char*(*get)(kvs_t*, const char*);
	int (*seek)(kvs_t*);
	int (*close)(kvs_t*);
	handle=dlopen("/home/kimseongyun/sp22f/kvs_lab/libkvs.so",RTLD_LAZY);
	if (!handle){
		fprintf(stderr, "%s\n", dlerror());
		exit(1);
	}
	open = (kvs_t*(*))dlsym(handle,"open");
	kvs_t* kvs = open();
	open();
	//open();
	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	}
#if 1
	// 2. put data 
	
	// 1) file read 
	// 2) put data 
 
	char key[100]; 
	char* value = (char*) malloc (sizeof(char)* 300);
	char* rvalue;

    FILE *file = fopen("student.dat","r");
	printf("Put operation ...\n");	

    while(1)
    {
		
		node_t* target = (node_t*)malloc(sizeof(node_t*));
        char *value_tmp = malloc(sizeof(char)*20);

		fscanf(file,"%s %s", key, value);
		strcpy(target->key, key);
		strcpy(value_tmp, value);
		target->value = value_tmp;

		if ((kvs->items)==0){
			kvs->db = target;
			(kvs->items)++;
			printf("PUT: %s %s\n", key, value);
			continue;
		}
		if(feof(file))break;
		put =(int(*)(kvs_t*, const char*, const char*))dlsym(handle, "put");
		if(put(kvs, key, value) < 0){
			printf("Failed to put data\n");
			exit(-1);
	}
	}
#endif

	// 1) file read 
	// 2) get & compare return value with original vallue 

#if 1
	printf("\nGet operation ...\n");		
	fseek(file,0,SEEK_SET);

	while(1)
    {
        fscanf(file,"%s %s", key, value);

        if(feof(file))break;
		get = (char*(*)(kvs_t*, const char*))dlsym(handle, "get");
		if(!(rvalue = get(kvs, key))){
			printf("Failed to get data\n");
			exit(-1);
		}

		printf("get: %s %s\n", key, rvalue);
	}
#endif

	// 4. print all items 
#if 1 
	printf("\nSeek operation ...\n");	

	seek = (int(*)(kvs_t*))dlsym(handle, "seek");

	seek(kvs);


	close = (int(*)(kvs_t*))dlsym(handle, "close");
	// 5. close 
	close(kvs);
#endif
	
	return 0;
}
