#include "kvs.h"

int main()
{
	// 1. create KVS
	kvs_t* kvs = open();
	//open();
	if(!kvs) {
		printf("Failed to open kvs\n");
		return -1;
	}
#if 1
	// 2. put data 
	
	// 1) file read 
	// 2) put data 
 
	char key[100]; 
	char* value = (char*) malloc (sizeof(char)* 300);
	char* rvalue;

    FILE *file = fopen("student.dat","r");
	printf("Put operation ...\n");	

    while(1)
    {
		
		node_t* target = (node_t*)malloc(sizeof(node_t*));
        char *value_tmp = malloc(sizeof(char)*20);

		fscanf(file,"%s %s", key, value);
		strcpy(target->key, key);
		strcpy(value_tmp, value);
		target->value = value_tmp;

		if ((kvs->items)==0){
			kvs->db = target;
			(kvs->items)++;
			printf("PUT: %s %s\n", key, value);
			continue;
		}
		if(feof(file))break;

		if(put(kvs, key, value) < 0){
			printf("Failed to put data\n");
			exit(-1);
	}
	}
#endif

	// 3. get for test 

	// 1) file read 
	// 2) get & compare return value with original vallue 

#if 1
	printf("\nGet operation ...\n");		
	fseek(file,0,SEEK_SET);

	while(1)
    {
        fscanf(file,"%s %s", key, value);

        if(feof(file))break;

		if(!(rvalue = get(kvs, key))){
			printf("Failed to get data\n");
			exit(-1);
		}

		printf("get: %s %s\n", key, rvalue);
	}
#endif

	// 4. print all items 
#if 1 
	printf("\nSeek operation ...\n");	

	seek(kvs);


	// 5. close 
	close(kvs);
#endif
	
	return 0;
}
