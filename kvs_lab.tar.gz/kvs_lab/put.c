#include "kvs.h"

int put(kvs_t* kvs, const char* key, const char* value)
{
	//어디에 추가할지 위치 찾기
	struct node* newnode = (struct node*)malloc(sizeof(struct node*));		
	struct node* tmp = kvs->db;
	for(int i=0;i<(kvs->items)-1;i++){
		tmp = tmp->next;
	}
	//추가할 노드 생성
	char *value_tmp = malloc(sizeof(char)*20);

	//추가할 노드에 값 대입
	strcpy(newnode->key, key);
	strcpy(value_tmp, value);
	newnode->value = value_tmp;

	//값 대입한 노드를 다음 노드로
	tmp->next = newnode;
	(kvs->items)++;	
	printf("PUT: %s %s\n", key, value);

	return 0;
}
